# 84000 Reading Room

The 84000 Reading Room eXist db app.

The app's public url is [read.84000.co](http://read.84000.co).

You can find out more about eXist at [exist-db.org](http://exist-db.org).

