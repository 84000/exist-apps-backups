# 84000 Utilities

The 84000 Utilities for data management, sharing and testing.

You can find out more about eXist at [exist-db.org](http://exist-db.org).
